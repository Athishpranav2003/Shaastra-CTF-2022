#include <bits/stdc++.h>
using namespace std;

int main(void)
{
	printf("Congrats on getting this file hidden inside the directree\n");
	printf("You just have to find flag from here on your own\n");
	string s="ShaastraCTF{D!rectree_depth_2_wa5_9u!ck_t0_traver5e}";
	printf("Happy Solving\n");
}
